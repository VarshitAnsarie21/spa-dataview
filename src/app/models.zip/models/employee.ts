export class Employee {
    // customerEmail: string;
    // customerPassword: string;
    // customerName: string;
    // customerMobile: string;
    // customerAddress: string;
    // customerPincode: string;
  }