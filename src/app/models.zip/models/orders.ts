export class Orders {
    // customerEmail: string;
    // customerPassword: string;
    // customerName: string;
    // customerMobile: string;
    // customerAddress: string;
    // customerPincode: string;
  }